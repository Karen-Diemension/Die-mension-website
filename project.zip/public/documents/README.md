# Document Assets Required

Please add the following document to this folder:

- `application.pdf` - Employee application form for job applicants to download

This PDF should be your company's official employment application form.
